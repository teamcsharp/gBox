"""Retarget profiles: the operator's own adjustments to how a donor character is fitted into one game (the Retarget
editor pop-up, clients/web/viz/retarget-editor.js).

A profile is stored per (donor character, target game[, slot]) in the character's meta.json:

    meta["retarget_profiles"][game_id][slot | "*"] = {
        "roles":  {role: donor bone name | ""},      # "specify what is what": which donor bone is which body role
                                                     #   ("" removes a role the automatic mapping guessed wrong)
        "height": 1.0,                               # whole figure, about the ground under the hip
        "ground": 0.0,                               # lift (+) / sink (-), a fraction of the target figure height
        "head": 1.0,                                 # head size, about the head joint
        "torso_width": 1.0,                          # torso x scale about the body centre; the limbs ride along
        "arm_length": 1.0, "leg_length": 1.0,        # every arm / leg segment along its bone
        "adjust": {role: {"length": 1, "girth": 1, "scale": [1, 1, 1], "offset": [0, 0, 0], "rotate": [0, 0, 0]}},
        "joints": {role: [dx, dy, dz]},              # the Goals view's circles: where that role's joint (its pivot) sits
                                                     #   on the DONOR, moved from where its rig put it - a fraction of
                                                     #   the donor's height in the editor frame (left +X, up +Y, front
                                                     #   +Z), each component within +-0.25 ("the elbow was guessed too
                                                     #   high": l_fore [0, -0.03, 0])
        "turn": true,                                # "Turn around": the fit frame turned 180 degrees about up (the
                                                     #   donor faces -Z with its left on -X) for a slot whose own
                                                     #   skeleton faces the other way; see turn_frame()
    }

"*" is the game-wide profile; a slot with its own (complete) profile uses that instead. Offsets are fractions of the target
figure height (game units differ: Mario's skeleton is ~100 units tall, DOA2's ~1.7), rotations are degrees (XYZ).

Writers apply a profile in four places:
  1. before fitting: apply_to_meta() returns the meta with the role overrides merged into rig.roles and the profile
     in rig.scale["profile"]; every writer already passes rig.roles to load_rig and rig.scale to retarget.
  2. the donor rig, before the fit: the shared retargets start with move_joints(rig, profile), which moves the donor
     joints of profile["joints"] (the Goals view's circles) and re-derives which limb segment owns the vertices a moved
     elbow / wrist / knee / ankle swept across, so the fit's pivots, limb rotations, stretch, segmentation and weights
     all use the moved joint: every writer that hands rig.scale to sm64_swap.retarget (SM64, OoT, PE1/2, FF7,
     SA2/JGR/PSO, SmackDown! 2, No Mercy/WCW, Def Jam, DOA++, Enter the Matrix), doa2_weighted_retarget (DOA2) or
     re4gc_enemies.retarget (RE4, Metal Arms, GTA III / Vice City / Stories). Writers that call those retargets
     without the profile (RE6, 007 AUF, MGS VR) or fit without them (Crazy Taxi's principal-axis parts, the sprite
     writers) do not honour joint moves (nor the rest of the profile, except Crazy Taxi's part_transform below).
  3. after the automatic fit, in target space: the shared retargets (sm64_swap.retarget - used by SM64, OoT, PE1/2,
     FF7, SA2/JGR/PSO through ninja_swap, SmackDown! 2, No Mercy/WCW, Def Jam - doa2_weighted_retarget.retarget and
     re4gc_enemies.retarget) call apply_jmap()/apply_roles() on their output. Crazy Taxi's principal-axis fit scales
     its parts with part_transform().
  4. "turn" (the editor's Turn around) is applied where the donor is stood in its fit frame: sm64_swap.retarget and
     doa2_weighted_retarget.retarget fit in turn_frame(facing(rig)), re4gc_enemies.retarget (whose rig arrives already
     upright) turns the rig about its hip first. The donor frame of joint moves and the shape cage (donor_frame) is
     NOT turned: the editor's donor views stay facing front. Writers that fit without those three retargets or call
     them without the profile (RE6, 007 AUF, MGS VR - which applies only the target-space step 3 -, Crazy Taxi,
     sprites) ignore it, like the joint moves.

"Swap left <-> right" needs nothing here: the editor saves it as ordinary role overrides (every l_* role names its r_*
twin's bone and back), which apply_to_meta merges into rig.roles like any other assignment.

Flags ("mapped wrong", the pick whip's "Fix this character's mapping"): meta["retarget_flags"][game_id][slot key] =
[{at, session_id, note, by}] (newest last, at most FLAGS_KEEP). Kept beside the profiles, not in them, so a flag never
creates a slot profile (which would shadow the game-wide one) nor changes a build's digest; saving or resetting that
slot's profile clears them (add_flag / flags_of / clear_flags).

The adjustment maths is pure numpy on prims ({pos, nrm, J, W}) and is tested on synthetic skeletons
(tests/test_retarget_profile.py); clients/web/viz/retarget-handles.js mirrors it for the editor's live preview.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math

import numpy as np

ROLES = ["hip", "chest", "neck", "head", "l_clav", "r_clav", "l_upper", "l_fore", "l_hand", "r_upper", "r_fore",
         "r_hand", "l_thigh", "l_shin", "l_foot", "r_thigh", "r_shin", "r_foot"]       # = sm64_swap.ORDER
TORSO = {"hip", "chest", "neck", "l_clav", "r_clav"}
ARMS = {"l_upper", "l_fore", "l_hand", "r_upper", "r_fore", "r_hand"}
LEGS = {"l_thigh", "l_shin", "l_foot", "r_thigh", "r_shin", "r_foot"}
CHILD = {"hip": "chest", "chest": "neck", "neck": "head", "l_clav": "l_upper", "r_clav": "r_upper",
         "l_upper": "l_fore", "l_fore": "l_hand", "r_upper": "r_fore", "r_fore": "r_hand",
         "l_thigh": "l_shin", "l_shin": "l_foot", "r_thigh": "r_shin", "r_shin": "r_foot"}
PARENT = {c: p for p, c in CHILD.items()}
ROOT = {r: ("l_upper" if r in ARMS and r[0] == "l" else "r_upper" if r in ARMS else
            "l_thigh" if r[0] == "l" else "r_thigh") for r in ARMS | LEGS}
SCALE_RANGE = (0.25, 4.0)
DEFAULT = {"roles": {}, "height": 1.0, "ground": 0.0, "head": 1.0, "torso_width": 1.0, "arm_length": 1.0,
           "leg_length": 1.0, "adjust": {}, "joints": {}}
JOINT_RANGE = 0.25                                       # a joint moves at most a quarter of the donor height per axis
LIMB_CHAINS = [("l_upper", "l_fore", "l_hand"), ("r_upper", "r_fore", "r_hand"),
               ("l_thigh", "l_shin", "l_foot"), ("r_thigh", "r_shin", "r_foot")]      # = sm64_swap.LIMBS
ADJUST_DEFAULT = {"length": 1.0, "girth": 1.0, "scale": [1.0, 1.0, 1.0], "offset": [0.0, 0.0, 0.0],
                  "rotate": [0.0, 0.0, 0.0]}
TURN = np.diag([-1.0, 1.0, -1.0])                        # 180 degrees about up: left -> -X, front -> -Z
FLAGS_KEEP = 20


# ---------------------------------------------------------------- the profile itself

def _num(v, default, lo, hi):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(f):
        return default
    return float(min(hi, max(lo, f)))


def _vec(v, default, lo, hi):
    if not isinstance(v, (list, tuple)) or len(v) != 3:
        return list(default)
    return [_num(x, d, lo, hi) for x, d in zip(v, default)]


def normalize(profile: dict | None) -> dict:
    """A clean profile: known keys only, numbers clamped to sane ranges, unknown roles dropped. Raises ValueError for
    something that is not a profile at all."""
    if profile is None:
        return copy.deepcopy(DEFAULT)
    if not isinstance(profile, dict):
        raise ValueError("a retarget profile is a JSON object")
    out = copy.deepcopy(DEFAULT)
    roles = profile.get("roles") or {}
    if not isinstance(roles, dict):
        raise ValueError("profile.roles maps a body role to a donor bone name")
    for role, bone in roles.items():
        if role not in ROLES:
            raise ValueError(f"unknown body role {role!r} (roles: {', '.join(ROLES)})")
        if bone is not None and not isinstance(bone, str):
            raise ValueError(f"profile.roles.{role} must be a bone name or empty")
        out["roles"][role] = (bone or "").strip()[:128]
    out["height"] = _num(profile.get("height"), 1.0, *SCALE_RANGE)
    out["ground"] = _num(profile.get("ground"), 0.0, -0.5, 0.5)
    out["head"] = _num(profile.get("head"), 1.0, *SCALE_RANGE)
    out["torso_width"] = _num(profile.get("torso_width"), 1.0, *SCALE_RANGE)
    out["arm_length"] = _num(profile.get("arm_length"), 1.0, *SCALE_RANGE)
    out["leg_length"] = _num(profile.get("leg_length"), 1.0, *SCALE_RANGE)
    adjust = profile.get("adjust") or {}
    if not isinstance(adjust, dict):
        raise ValueError("profile.adjust maps a body role to its adjustment")
    for role, a in adjust.items():
        if role not in ROLES:
            raise ValueError(f"unknown body role {role!r} in profile.adjust")
        a = a if isinstance(a, dict) else {}
        clean = {"length": _num(a.get("length"), 1.0, *SCALE_RANGE), "girth": _num(a.get("girth"), 1.0, *SCALE_RANGE),
                 "scale": _vec(a.get("scale"), [1.0] * 3, *SCALE_RANGE),
                 "offset": _vec(a.get("offset"), [0.0] * 3, -1.0, 1.0),
                 "rotate": _vec(a.get("rotate"), [0.0] * 3, -180.0, 180.0)}
        if clean != ADJUST_DEFAULT:
            out["adjust"][role] = clean
    joints = profile.get("joints") or {}
    if not isinstance(joints, dict):
        raise ValueError("profile.joints maps a body role to its joint move [dx, dy, dz]")
    for role, d in joints.items():
        if role not in ROLES:
            raise ValueError(f"unknown body role {role!r} in profile.joints")
        v = [round(x, 6) for x in _vec(d, [0.0] * 3, -JOINT_RANGE, JOINT_RANGE)]
        if any(abs(x) > 1e-6 for x in v):
            out["joints"][role] = v
    for k in ("notes", "updated", "by"):
        if isinstance(profile.get(k), (str, int, float)):
            out[k] = profile[k] if not isinstance(profile[k], str) else profile[k][:500]
    if "lattice" in profile:
        from .shape_lattice import normalize as clean_lattice
        cage = clean_lattice(profile["lattice"])
        if cage["offsets"]:
            out["lattice"] = cage
    if profile.get("plant_feet") is True:
        out["plant_feet"] = True
    if profile.get("preserve_geometry") is True:
        out["preserve_geometry"] = True
    if profile.get("turn") is True:
        out["turn"] = True
    if isinstance(profile.get("shoe_tops"), dict):
        tops = {s: _num(profile['shoe_tops'][s], .15, 0, .5) for s in ('l', 'r') if s in profile['shoe_tops']}
        if tops: out['shoe_tops'] = tops
    return out


def is_identity(profile: dict | None) -> bool:
    """True when the profile changes nothing about the fitted geometry (role overrides aside)."""
    if not profile:
        return True
    p = normalize(profile)
    return (not p["adjust"] and not p["joints"] and not p.get("lattice") and not p.get("plant_feet") and not p.get('shoe_tops') and not p.get('preserve_geometry') and not p.get("turn") and all(p[k] == DEFAULT[k] for k in ("height", "ground", "head",
                                                                                     "torso_width", "arm_length",
                                                                                     "leg_length")))


def digest(profile: dict | None) -> str:
    """A short stable hash of what a profile changes (cache keys: a changed profile rebuilds the mod)."""
    if not profile:
        return ""
    p = {k: v for k, v in normalize(profile).items() if k not in ("notes", "updated", "by")}
    if is_identity(p) and not p["roles"]:
        return ""
    return hashlib.sha256(json.dumps(p, sort_keys=True).encode()).hexdigest()[:12]


def slot_key(slot: str | None) -> str:
    """'fighter:Kasumi:all' -> 'fighter:kasumi'; '' / 'all' / '*' -> '*' (the game-wide profile)."""
    s = str(slot or "").strip().casefold()
    if s.endswith(":all"):
        s = s[:-4]
    return s if s and s not in ("*", "all", "roster", "cast") else "*"


def stored(meta: dict, game_id: str) -> dict:
    """{slot key: raw profile} stored for one game."""
    return dict(((meta or {}).get("retarget_profiles") or {}).get(game_id) or {})


def resolve(meta: dict, game_ids, slot: str | None = None) -> dict | None:
    """The profile for this donor in this game, or None when the operator never made one: the slot's own profile when
    it has one (a complete profile: the editor starts it from the game-wide one), else the game-wide "*" profile.
    game_ids: one id or several (a writer serving a game's regional releases)."""
    ids = [game_ids] if isinstance(game_ids, str) else list(game_ids or [])
    profiles = (meta or {}).get("retarget_profiles") or {}
    for gid in ids:
        entry = profiles.get(gid)
        if not entry:
            continue
        key = slot_key(slot)
        game_wide, own = entry.get("*"), entry.get(key) if key != "*" else None
        if own is None and key != "*":                      # 'fighter:kasumi' also matches a profile saved as 'kasumi'
            own = entry.get(key.split(":", 1)[-1])
        if game_wide is None and own is None:
            continue
        return normalize(own if own is not None else game_wide)
    return None


def apply_to_meta(meta: dict, game_ids, slot: str | None = None) -> dict:
    """The meta a writer should fit with: role overrides merged into rig.roles, the profile in rig.scale['profile'].
    Returns meta unchanged (the same object) when there is no profile, so builds without one are byte-identical."""
    prof = resolve(meta, game_ids, slot)
    if prof is None:
        return meta
    out = copy.deepcopy(meta)
    rig = out.setdefault("rig", {})
    roles = dict(rig.get("roles") or {})
    for role, bone in prof["roles"].items():
        if bone:
            for other, b in list(roles.items()):            # a bone keeps one role: the operator's assignment wins
                if b == bone and other != role:
                    roles.pop(other)
            roles[role] = bone
        else:
            roles.pop(role, None)
    rig["roles"] = roles
    if not is_identity(prof):
        rig["scale"] = dict(rig.get("scale") or {}) | {"profile": prof}
    out["retarget_profile_digest"] = digest(prof)
    return out


def profile_of(scale) -> dict | None:
    """The profile a writer passed through rig.scale (None when there is none or it changes nothing)."""
    p = (scale or {}).get("profile") if isinstance(scale, dict) else None
    return None if not p or is_identity(p) else normalize(p)


def turned(profile: dict | None) -> bool:
    """True when the profile asks for Turn around."""
    return bool(profile) and normalize(profile).get("turn") is True


def turn_frame(B, profile: dict | None) -> np.ndarray:
    """The fit frame (rows: left, up, front) turned 180 degrees about up when the profile says turn: the donor then
    faces -Z with its left on -X, matching a slot skeleton that faces the other way. B unchanged otherwise."""
    B = np.asarray(B, float)
    return TURN @ B if turned(profile) else B


def turn_rig(rig: dict, profile: dict | None) -> dict:
    """An upright rig (left +X, up +Y, front +Z: re4gc_enemies.retarget's input) turned 180 degrees about up through
    its hip when the profile says turn (a shallow copy); the rig itself otherwise."""
    if not turned(profile):
        return rig
    S = np.asarray(rig["joints"], float)
    ri = rig.get("roles") or {}
    c = S[ri["hip"]] if "hip" in ri else S.mean(0)
    piv = np.array([c[0], 0.0, c[2]])
    turn = lambda P: (np.asarray(P, float) - piv) @ TURN.T + piv          # noqa: E731
    prims = [{**p, "pos": turn(p["pos"]), "nrm": np.asarray(p["nrm"], float) @ TURN.T} for p in rig["prims"]]
    return {**rig, "joints": turn(S), "prims": prims}


# ---------------------------------------------------------------- "mapped wrong" flags from gameplay

def flags_of(meta: dict, game_id: str, slot: str | None) -> list[dict]:
    """The flags raised for this donor in this game's slot (a 'fighter:kas' slot also reads flags kept as 'kas')."""
    entry = (((meta or {}).get("retarget_flags") or {}).get(game_id)) or {}
    key = slot_key(slot)
    got = entry.get(key)
    if got is None and ":" in key:
        got = entry.get(key.split(":", 1)[-1])
    return [dict(f) for f in (got or []) if isinstance(f, dict)]


def add_flag(meta: dict, game_id: str, slot: str | None, flag: dict) -> list[dict]:
    """Record one flag on meta (mutated): {at, session_id, note, by}, strings trimmed, newest last, FLAGS_KEEP kept."""
    clean = {"at": _num(flag.get("at"), 0.0, 0.0, 1e12), "session_id": str(flag.get("session_id") or "")[:120],
             "note": str(flag.get("note") or "").strip()[:500], "by": str(flag.get("by") or "")[:80]}
    entry = meta.setdefault("retarget_flags", {}).setdefault(game_id, {})
    rows = [f for f in entry.get(slot_key(slot)) or [] if isinstance(f, dict)] + [clean]
    entry[slot_key(slot)] = rows[-FLAGS_KEEP:]
    return entry[slot_key(slot)]


def clear_flags(meta: dict, game_id: str, slot: str | None) -> int:
    """Remove the flags a save / reset of that profile answers (meta mutated): the slot's own ('kas' too for
    'fighter:kas'); the game-wide profile ('*') answers every slot of the game. Returns how many went."""
    games = (meta or {}).get("retarget_flags") or {}
    entry = games.get(game_id) or {}
    key = slot_key(slot)
    keys = list(entry) if key == "*" else [k for k in (key, key.split(":", 1)[-1]) if k in entry]
    n = 0
    for k in dict.fromkeys(keys):
        n += len(entry.pop(k) or [])
    if game_id in games and not entry:
        games.pop(game_id)
    if "retarget_flags" in (meta or {}) and not games:
        meta.pop("retarget_flags")
    return n


# ---------------------------------------------------------------- the maths (target space, +Y up)

def _euler(deg) -> np.ndarray:
    x, y, z = (math.radians(float(a)) for a in deg)
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return rz @ ry @ rx


def _axis(role: str, pos: dict) -> np.ndarray:
    """The bone direction of a role: towards its child joint, else continuing from its parent, else +Y."""
    p = pos[role]
    if CHILD.get(role) in pos:
        d = pos[CHILD[role]] - p
    elif PARENT.get(role) in pos:
        d = p - pos[PARENT[role]]
    else:
        d = np.array([0.0, 1.0, 0.0])
    n = float(np.linalg.norm(d))
    return d / n if n > 1e-9 else np.array([0.0, 1.0, 0.0])


def frame(role_pos: dict, ground: float | None = None) -> dict:
    """Reference points of the target figure: centre (hip x/z), ground y and figure height H (head over ground)."""
    pos = {r: np.asarray(v, float) for r, v in role_pos.items()}
    pts = np.array(list(pos.values())) if pos else np.zeros((1, 3))
    centre = pos.get("hip", pts.mean(0))
    g = float(ground) if ground is not None else float(pts[:, 1].min())
    top = pos["head"][1] if "head" in pos else float(pts[:, 1].max())
    return {"centre": centre, "ground": g, "H": max(float(top - g), 1e-6)}


def role_transforms(role_pos: dict, profile: dict, ground: float | None = None) -> tuple[dict, tuple]:
    """{role: (A 3x3, t 3)} with x' = A x + t for every role that has a target position, plus the transform used
    for vertices on joints without a role (the torso family: torso width + global height/ground)."""
    prof = normalize(profile)
    pos = {r: np.asarray(v, float) for r, v in role_pos.items() if r in ROLES}
    f = frame(pos, ground)
    c, H = f["centre"], f["H"]
    gpt = np.array([c[0], f["ground"], c[2]])
    k, lift = prof["height"], prof["ground"] * H
    G = np.eye(3) * k                                        # global: x -> gpt + k (x - gpt) + lift
    g_t = gpt - k * gpt + np.array([0.0, lift, 0.0])
    tw = prof["torso_width"]
    Wx = np.diag([tw, 1.0, 1.0])                            # torso width about the centre's x
    w_t = np.array([c[0] - tw * c[0], 0.0, 0.0])

    def compose(A, t):                                      # global after (A, t)
        return G @ A, G @ t + g_t

    out = {}
    for role, p in pos.items():
        a = prof["adjust"].get(role, ADJUST_DEFAULT)
        length = a["length"] * (prof["arm_length"] if role in ARMS else prof["leg_length"] if role in LEGS else 1.0)
        girth = a["girth"]
        d = _axis(role, pos)
        L = girth * np.eye(3) + (length - girth) * np.outer(d, d)
        S = np.diag(a["scale"])
        if role == "head":
            S = S * prof["head"]
        M = _euler(a["rotate"]) @ L @ S
        t = p - M @ p + np.asarray(a["offset"], float) * H   # about the role's own joint, then moved
        if role in TORSO:
            M, t = Wx @ M, Wx @ t + w_t
        else:                                               # limbs / head ride along with their root joint's x shift
            root = pos.get(ROOT.get(role, role), p)
            t = t + np.array([(tw - 1.0) * (root[0] - c[0]), 0.0, 0.0])
        out[role] = compose(M, t)
    return out, compose(Wx, w_t)


def apply_roles(prims: list[dict], role_pos: dict, joint_role: dict, profile: dict | None,
                ground: float | None = None) -> tuple[list[dict], dict]:
    """Apply a profile to fitted prims. role_pos: {role: target joint position}; joint_role: {native joint index:
    role} for the indices in prims' J. Each vertex blends its influences' role transforms by weight (single-weight
    prims just take their joint's). Returns (new prims, report); prims are returned as they were when the profile
    changes nothing."""
    prof = profile_of({"profile": profile}) if profile else None
    if prof is None:
        return prims, {"applied": False}
    tr, other = role_transforms(role_pos, prof, ground)
    nj = 1 + max([int(np.max(np.asarray(p["J"]))) for p in prims if len(np.asarray(p.get("J", [])))] + [0]
                 + [int(j) for j in joint_role])
    A = np.repeat(other[0][None], nj, 0)
    T = np.repeat(other[1][None], nj, 0)
    for j, role in joint_role.items():
        if role in tr and 0 <= int(j) < nj:
            A[int(j)], T[int(j)] = tr[role]
    Ainv_t = np.linalg.inv(A).transpose(0, 2, 1)
    out, shift = [], 0.0
    for p in prims:
        P, N = np.asarray(p["pos"], float), np.asarray(p.get("nrm", np.zeros_like(p["pos"])), float)
        J = np.asarray(p["J"], int)
        if J.ndim == 1:
            J = J[:, None]
        W = np.asarray(p["W"], float) if "W" in p else np.zeros(J.shape)
        if W.shape != J.shape:
            W = np.zeros(J.shape)
        if "W" not in p or not np.any(W):
            W = np.zeros(J.shape)
            W[:, 0] = 1.0
        tot = W.sum(1, keepdims=True)
        W = np.where(tot > 1e-12, W / np.maximum(tot, 1e-12), np.eye(J.shape[1])[0][None])
        newP = np.einsum("nk,nkij,nj->ni", W, A[J], P) + np.einsum("nk,nki->ni", W, T[J])
        newN = np.einsum("nk,nkij,nj->ni", W, Ainv_t[J], N)
        newN /= np.maximum(np.linalg.norm(newN, axis=1, keepdims=True), 1e-12)
        if len(P):
            shift = max(shift, float(np.abs(newP - P).max()))
        out.append({**p, "pos": newP, "nrm": newN})
    f = frame(role_pos, ground)
    planted = {"applied": False}
    if prof.get("plant_feet"):
        feet = {int(j) for j, role in joint_role.items() if role in ("l_foot", "r_foot")}
        floors = []
        for p in out:
            if p.get("prop"):
                continue
            j = np.asarray(p["J"], int)
            if j.ndim == 1:
                j = j[:, None]
            w = np.asarray(p.get("W", np.ones(j.shape)), float)
            owner = j[np.arange(len(j)), w.argmax(1)]
            selected = np.isin(owner, list(feet))
            if selected.any():
                floors.append(float(np.asarray(p["pos"])[selected, 1].min()))
        if floors:
            lift = f["ground"] + prof["ground"] * f["H"] - min(floors)
            out = [{**p, "pos": np.asarray(p["pos"]) + [0, lift, 0]} for p in out]
            planted = {"applied": True, "lift": float(lift), "measured_floor": min(floors)}
    return out, {"applied": True, "height": prof["height"], "ground": prof["ground"], "head": prof["head"],
                 "torso_width": prof["torso_width"], "arm_length": prof["arm_length"],
                 "leg_length": prof["leg_length"], "roles_adjusted": sorted(prof["adjust"]),
                 "max_shift": round(shift / f["H"], 4), "feet": planted}


def apply_jmap(prims: list[dict], T, jmap: dict, profile: dict | None, ground: float | None = None):
    """apply_roles for retargets that hold the target as joint positions T[index] and a {role: index} map."""
    if not profile:
        return prims, {"applied": False}
    T = np.asarray(T, float)
    role_pos = {r: T[j] for r, j in jmap.items() if r in ROLES and isinstance(j, (int, np.integer)) and 0 <= j < len(T)}
    joint_role = {}
    for role in ROLES:                                      # a joint keeps its first role (sm64_swap.ORDER)
        j = jmap.get(role)
        if isinstance(j, (int, np.integer)) and int(j) not in joint_role:
            joint_role[int(j)] = role
    return apply_roles(prims, role_pos, joint_role, profile, ground)


# ---------------------------------------------------------------- joint moves (the donor rig, before the fit)

def _unit(v) -> np.ndarray:
    n = float(np.linalg.norm(v))
    return np.asarray(v, float) / n if n > 1e-12 else np.zeros(3)


def boundary_normal(parent, joint, child=None) -> np.ndarray:
    """The plane through a limb joint that splits its parent segment from its own: the bisector of the two bone
    directions (just the parent bone's direction at a chain's end)."""
    n = _unit(np.asarray(joint, float) - parent) + (_unit(np.asarray(child, float) - joint) if child is not None
                                                     else 0.0)
    return _unit(n) if np.linalg.norm(n) > 1e-9 else _unit(np.asarray(joint, float) - parent)


def resegment(points, roles, old: dict, new: dict, chain: tuple) -> np.ndarray:
    """Vertex roles of one limb chain after its joints moved: a vertex the moved elbow / wrist (knee / ankle) plane
    swept across changes segment, every other vertex keeps its role. points (N,3); roles (N,) role names; old / new:
    {role: joint position} before / after the move (same axes as points). Returns the new role per vertex."""
    out = np.asarray(roles, dtype=object).copy()
    P = np.asarray(points, float).reshape(-1, 3)
    for i in (1, 2):                                       # the joints inside the chain: fore / hand, shin / foot
        if i >= len(chain):
            break
        par, x = chain[i - 1], chain[i]
        nxt = chain[i + 1] if i + 1 < len(chain) else None
        if par not in old or x not in old:
            continue
        if all(np.allclose(old[r], new[r]) for r in (par, x, nxt) if r in old):
            continue                                       # this boundary's plane did not move
        n0 = boundary_normal(old[par], old[x], old.get(nxt) if nxt else None)
        n1 = boundary_normal(new[par], new[x], new.get(nxt) if nxt else None)
        s0, s1 = (P - old[x]) @ n0 > 0, (P - new[x]) @ n1 > 0
        out[(out == par) & s1 & ~s0] = x                   # the joint moved towards the body: these now bend with x
        out[(out == x) & s0 & ~s1] = par                   # moved away: these stay with the parent segment
    return out


def donor_frame(rig: dict) -> tuple[np.ndarray, float]:
    """(B, H): the facing rotation (rows: left, up, front in the rig's own axes, sm64_swap.facing) and the donor's
    height (the mesh's extent along up) - the frame the Goals view's joint moves are measured in."""
    from .sm64_swap import facing
    B = facing(rig)
    allp = np.concatenate([np.asarray(p["pos"], float).reshape(-1, 3) for p in rig["prims"]])
    return B, max(float(np.ptp(allp @ B[1])) if len(allp) else 1.0, 1e-9)


def move_joints(rig: dict, profile: dict | None) -> tuple[dict, dict]:
    """The donor rig with profile["joints"] applied (a shallow copy; the input is not mutated): each moved role's
    joint at its new place (descendant joints stay), and the vertices the moved limb joints swept across re-owned by
    their new segment (owner, and J where a prim carries weights: influences of the chain's two segments go to the
    new one). Returns (rig, report); the rig itself when nothing moves, so builds without joint moves are unchanged."""
    prof = profile_of({"profile": profile}) if profile else None
    if prof and prof.get("lattice"):
        from .shape_lattice import apply as shape_donor
        rig = shape_donor(rig, prof["lattice"])
    ri = rig.get("roles") or {}
    moves = {r: np.asarray(d, float) for r, d in (prof or {}).get("joints", {}).items() if r in ri}
    tops = (prof or {}).get('shoe_tops') or {}
    for side in tops:
        foot, shin = side+'_foot', side+'_shin'
        if foot not in ri or shin not in ri or ri[foot] == ri[shin]:
            raise ValueError(f'Specify distinct {side} shin and foot bones before applying shoe boundaries')
    if not moves and not tops:
        return rig, {"moved": []}
    from .formats.rig import role_of_joint
    B, Hd = donor_frame(rig)
    old_j = np.asarray(rig["joints"], float)
    new_j = old_j.copy()
    for r, d in moves.items():
        new_j[ri[r]] = old_j[ri[r]] + (d * Hd) @ B          # editor frame -> the rig's axes (B is orthonormal)
    jrole = np.array(role_of_joint({"roles": ri, "parent": rig["parent"]}), dtype=object)
    old = {r: old_j[j] for r, j in ri.items()}
    new = {r: new_j[j] for r, j in ri.items()}
    chains = [c for c in LIMB_CHAINS if any(r in moves for r in c) and c[0] in ri and c[1] in ri]
    prims, changed = [], 0
    body = [np.asarray(p['pos']) @ B[1] for p in rig['prims'] if len(p['pos']) and not p.get('prop')]
    floor = min((float(y.min()) for y in body), default=0)
    body_height = max((float(y.max()) for y in body), default=1) - floor
    for p in rig["prims"]:
        owner = np.asarray(p["owner"], int)
        before = jrole[owner]
        after = before.copy()
        for c in chains:
            after = resegment(p["pos"], after, old, new, tuple(r for r in c if r in ri))
        if tops and not p.get('prop'):
            # Explicit shoe tops separate shoes from a shin even when source ownership was wrong.
            y = np.asarray(p['pos']) @ B[1]
            for side, fraction in tops.items():
                foot, shin = side+'_foot', side+'_shin'
                leg = np.isin(after, [side+'_thigh', shin, foot])
                below = y <= floor + fraction * body_height
                after[leg & below] = foot
                after[leg & ~below & (after == foot)] = shin
        diff = np.nonzero(after != before)[0]
        if not len(diff):
            prims.append(p)
            continue
        changed += len(diff)
        own = owner.copy()
        own[diff] = [ri[r] for r in after[diff]]
        q = {**p, "owner": own}
        if p.get("J") is not None and np.ndim(p["J"]) == 2:
            J = np.asarray(p["J"], int).copy()
            for v in diff:
                pair = {before[v], after[v]}
                for col in range(J.shape[1]):
                    if jrole[J[v, col]] in pair:
                        J[v, col] = ri[after[v]]
            q["J"] = J
        prims.append(q)
    return ({**rig, "joints": new_j, "prims": prims},
            {"moved": sorted(moves), "shoe_tops": tops, "vertices_reassigned": int(changed), "donor_height": round(Hd, 4)})


def goals(donor_pos: dict, target_pos: dict, donor_ground: float | None = None,
          target_ground: float | None = None) -> dict:
    """What the fit aims at, for the Fitting pop-up and the Retarget editor's Goals view: each role's donor joint
    (the editor frame, donor units) and the target slot's joint it lands on (target space, +Y up)."""
    def clean(pos):
        out = {}
        for r, v in (pos or {}).items():
            v = np.asarray(v, float).reshape(-1)
            if r in ROLES and len(v) == 3 and np.isfinite(v).all():
                out[r] = [round(float(x), 5) for x in v]
        return out
    g = {"donor": clean(donor_pos), "target": clean(target_pos)}
    for k, v in (("donor_ground", donor_ground), ("target_ground", target_ground)):
        if v is not None and math.isfinite(float(v)):
            g[k] = round(float(v), 5)
    return g


def part_transform(role: str | None, role_pos: dict, profile: dict | None, ground: float | None = None):
    """(A, t) for a rigid part that belongs to one role (Crazy Taxi's per-part fit), identity without a profile."""
    prof = profile_of({"profile": profile}) if profile else None
    if prof is None:
        return np.eye(3), np.zeros(3)
    tr, other = role_transforms(role_pos, prof, ground)
    return tr.get(role, other) if role else other
