"""RE5 proximity bombs through game-created loadouts and ordinary pad input.

The spawn-template schema is the existing, verified BLUS30491 inventory constructor.
Existing inventory identities are never relabelled. A quantity decrement acknowledges
use; it does not establish that an enemy was killed by that mine.
"""
import json
import math
import struct
from pathlib import Path

from ..deployables import Cadence
from . import re5_weapons as W

DEFAULT = {"enabled": True, "interval_s": 60., "only": False}


def settings_path():
    from .. import lessons
    return lessons.ROOT.parent / "re5-mine-settings.json"


def settings():
    try:
        data = json.loads(settings_path().read_text(encoding="utf-8"))
        test = Cadence(data["interval_s"], data["only"], data["enabled"])
        return {"enabled": test.enabled, "interval_s": test.interval, "only": test.only}
    except (OSError, ValueError, TypeError, KeyError):
        return dict(DEFAULT)


def configure(interval=60., only=False, enabled=True):
    c = Cadence(interval, only, enabled)
    data = {"enabled": c.enabled, "interval_s": c.interval, "only": c.only}
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data), encoding="utf-8")
    tmp.replace(path)
    return data


ORIGINAL_BANKS = (0x0172C688, 0x0172DB28)  # pristine solo/duo records match observed original Jill inventory


def _bank(g, address, blocks, key):
    from ... import re5_mods_tool as M
    current = g.rd(address, blocks * M.TEMPLATE_BLOCK)
    g.keep(key, lambda: current)
    data = bytearray(current)
    changed = 0
    for block in range(blocks):
        base = block * M.TEMPLATE_BLOCK
        rows = [struct.unpack_from(">11I", current, base + i*M.TEMPLATE_REC) for i in range(12)]
        # A zero-ID record is an unused, game-owned grid slot, not an arbitrary empty memory region.
        mines = [i for i,r in enumerate(rows) if r[0] == 0x10A and r[5] < 9]
        target = mines[0] if mines else next((i for i,r in enumerate(rows) if r[5] == 7), None)
        if target is None:
            # Some costumes omit grid 7 entirely and duplicate other empty grid numbers.
            # The constructor accepts an unused record assigned to the vacant quick slot.
            target = next((i for i,r in enumerate(rows) if r[0] == 0 and r[5] < 9), None)
        if target is None: continue
        if rows[target][0] not in (0, 0x10A):
            vacant = next((i for i,r in enumerate(rows) if r[0] == 0 and r[5] < 9), None)
            occupied = {r[5] for r in rows if r[0] and r[5] < 9}
            free_grid = next((x for x in range(9) if x != 7 and x not in occupied), None)
            if vacant is None or free_grid is None: continue
            moved = list(rows[target]); moved[5] = free_grid
            struct.pack_into(">11I", data, base+vacant*M.TEMPLATE_REC, *moved)
        # Use a quick slot. If the existing mine occupies a different grid, swap grid positions.
        if mines and rows[target][5] != 7:
            other = next((i for i,r in enumerate(rows) if r[5] == 7), None)
            if other is not None:
                moved = list(rows[other]); moved[5] = rows[target][5]
                struct.pack_into(">11I", data, base+other*M.TEMPLATE_REC, *moved)
        struct.pack_into(">11I", data, base+target*M.TEMPLATE_REC,
                         0x10A, 5, 0xffffffff, 0xffffffff, 0xffffffff, 7, 0, 0, 0, 0, 0)
        changed += 1
    return g.wr(address, bytes(data)), changed


def templates(g):
    from ... import re5_mods_tool as M
    if g.u32(M.TEMPLATE + M.TEMPLATE_SIGNATURE[0]) != M.TEMPLATE_SIGNATURE[1]:
        raise ValueError("mine loadout: build template signature differs")
    for address in ORIGINAL_BANKS:
        if g.u32(address + 3*M.TEMPLATE_REC) != 0x10E or g.u32(address + 5*M.TEMPLATE_REC) != 0x100:
            raise ValueError("original Mercenaries mine bank signature differs")
    ok, changed = _bank(g, M.TEMPLATE, M.TEMPLATE_BLOCKS, "template")
    for address in ORIGINAL_BANKS:
        good, count = _bank(g, address, 10, f"mine_bank_{address:x}")
        ok &= good
        changed += count
    # Permit consumption as acknowledgement. Refill only the existing mine's quantity afterward.
    ok &= g.wr(M.DEF_TABLE + 0x0A*M.DEF_STRIDE + M.DEF_NOAMMO, struct.pack(">I", 0))
    return {"verified": ok, "mine_loadout_blocks": changed, "effective_next_round": True}


class Controller:
    def __init__(self, memory, stats, switch):
        self.m, self.stats, self.switch = memory, stats, switch
        self.cadence = Cadence()
        self.pending = None
        self.config_at = -math.inf
        self.retry_at = 0.
        self.equip_until = 0.
        self.restore = None

    def tick(self, snap, now):
        if now-self.config_at >= 2:
            cfg = settings(); self.cadence.configure(cfg["interval_s"], cfg["only"], cfg["enabled"])
            self.config_at = now
        self.stats.update(mine_interval_s=self.cadence.interval, mines_only=self.cadence.only,
                          mines_enabled=self.cadence.enabled)
        if not self.cadence.enabled:
            self.pending = None
            self.restore = None
            return None
        p = snap.get("player")
        busy = not p or snap.get("recovery_active") or snap.get("prompt") or snap.get("stage_prompt") \
            or p.get("action") in (4,5) or (p.get("hp") or 0) <= 0
        if busy:
            return None
        if self.restore is not None:
            gun = next((w for w in snap.get("inventory", ())
                        if W.inventory_key(w) == self.restore), None)
            if gun is None or gun.get("hand"):
                self.restore = None
            else:
                return self.switch(gun, now, "restore gun after mine") or {"hold":set()}
        mine = next((w for w in snap.get("inventory", ()) if w.get("id") == 0x10A and W.quick_key(w)), None)
        if mine is None:
            self.stats["mine_status"] = "Waiting for the next game-created mine loadout"
            return None
        if self.pending:
            pen = self.pending
            if mine["slot"] != pen["slot"] or p["ptr"] != pen["player"]:
                self.pending = None
                return None
            if mine["rounds"] < pen["count"]:
                self.stats["mines_placed"] = self.stats.get("mines_placed",0)+1
                self.stats["mine_status"] = "Placement confirmed by item consumption"
                self.cadence.acknowledge(now,p["pos"])
                ad = getattr(self.m,"adapter",None)
                if ad is not None:
                    from ...re5_mods_tool import RE5, INV_OFS, SLOT
                    g=RE5(ad); addr=p["ptr"]+INV_OFS+mine["slot"]*SLOT+0xC
                    if g.u32(addr) == mine["rounds"]:
                        self.stats["mine_refill_verified"] = g.wr(addr,struct.pack(">I",5))
                self.pending = None
                gun = next((w for w in snap.get("inventory",()) if W.quick_key(w) and w.get("type")==1
                            and w.get("item") in W.WEAPONS and W.WEAPONS[w["item"]].family in W.DIRECT), None)
                if gun and not self.cadence.only:
                    self.restore = W.inventory_key(gun)
                    return self.switch(gun,now,"restore gun after mine") or {"hold":set()}
                return {"hold":set()}
            if now-pen["at"] > 4:
                self.stats["mine_status"] = "Placement unconfirmed; retry deferred"
                self.pending=None; self.retry_at=now+5
                return {"hold":set()}
            age=now-pen["at"]
            return {"hold": {"l1","r1"} if .35 <= age < .65 else ({"l1"} if age<.35 else set())}
        if now < self.retry_at or not self.cadence.due(now,p["pos"]):
            return None
        # Leave room to retreat; a nearby explosion can stagger even a modified character.
        if any((e.get("hp") or 0)>0 and math.dist(p["pos"],e["pos"])<350 for e in snap.get("enemies",())):
            self.stats["mine_status"] = "Waiting for deployment space"
            return None
        if not mine.get("hand"):
            self.stats["mine_status"] = "Equipping proximity bomb"
            if now < self.equip_until:
                return {"hold":set()}
            action = self.switch(mine,now,"scheduled proximity bomb")
            if action is not None:
                self.equip_until = now + 3
            return action
        self.pending={"at":now,"count":mine["rounds"],"slot":mine["slot"],"player":p["ptr"]}
        self.stats["mine_attempts"]=self.stats.get("mine_attempts",0)+1
        return {"hold":{"l1"}}
