import struct
from types import SimpleNamespace

from gbox import re5_mods_tool as T
from gbox.mercs.titles import re5_mines as M
from test_re5_mods import FakeRE5, fresh_originals  # noqa: F401


def template_game():
    m = FakeRE5()
    for b in range(T.TEMPLATE_BLOCKS):
        for i,grid in enumerate((0,2,4,9,10,11,3,1,5,7,6,8)):
            item = 0x124 if grid==9 else 0x112 if grid==3 else 0x304 if grid==7 else 0
            m.put(T.TEMPLATE+b*T.TEMPLATE_BLOCK+i*T.TEMPLATE_REC,
                  struct.pack(">11I",item,0xffffffff,0xffffffff,0xffffffff,0xffffffff,grid,int(grid==3),0,0,0,0))
    raw=m.read_memory(T.TEMPLATE,10*T.TEMPLATE_BLOCK)
    for address in M.ORIGINAL_BANKS:
        m.put(address,raw)
        m.u32(address+3*T.TEMPLATE_REC,0x10e)
        m.u32(address+5*T.TEMPLATE_REC,0x100)
    return m


def test_mines_use_spawn_templates_preserving_existing_items_and_live_inventory():
    m=template_game(); g=T.RE5(m)
    before_live=g.rd(0x303f8a00+T.INV_OFS,24*T.SLOT)
    result=M.templates(g)
    assert result["verified"] and result["mine_loadout_blocks"]==50
    records=T.template_records(g.rd(T.TEMPLATE,T.TEMPLATE_BLOCKS*T.TEMPLATE_BLOCK))
    for b in range(30):
        group=[r for r in records if r[0]//T.TEMPLATE_BLOCK==b]
        assert any(r[1]==0x10a and r[3]==7 and r[2]==5 for r in group)
        assert any(r[1]==0x304 and r[3]!=7 for r in group)
        assert any(r[1]==0x112 and r[3]==3 and r[4]==1 for r in group)
    assert g.rd(0x303f8a00+T.INV_OFS,24*T.SLOT)==before_live
    assert g.u32(T.DEF_TABLE+10*T.DEF_STRIDE+T.DEF_NOAMMO)==0


def test_mine_controller_does_not_count_a_press_or_interrupted_attempt(monkeypatch):
    monkeypatch.setattr(M,"settings",lambda:dict(M.DEFAULT,interval_s=2))
    stats={}; c=M.Controller(SimpleNamespace(),stats,lambda *a:{"tap":"ddown"})
    mine={"id":0x10a,"item":10,"type":1,"slot":2,"grid":7,"rounds":5,"hand":True}
    snap={"player":{"ptr":0x303f8a00,"pos":(0,0,0),"hp":1000,"action":0},"inventory":[mine]}
    assert c.tick(snap,0) is None
    assert c.tick(snap,3)=={"hold":{"l1"}}
    assert c.tick(snap,3.4)=={"hold":{"l1","r1"}}
    assert stats.get("mines_placed",0)==0
    assert c.tick(dict(snap,prompt="mash"),3.5) is None
    assert stats.get("mines_placed",0)==0
    c.tick(snap,8)
    assert stats.get("mines_placed",0)==0 and "unconfirmed" in stats["mine_status"]


def test_loadout_with_no_grid_seven_uses_an_empty_constructor_record():
    m=template_game();g=T.RE5(m)
    for b in range(T.TEMPLATE_BLOCKS):
        # Four live costumes omit an empty grid-seven record.
        address=T.TEMPLATE+b*T.TEMPLATE_BLOCK+9*T.TEMPLATE_REC
        m.put(address,struct.pack('>11I',0,0xffffffff,0xffffffff,0xffffffff,0xffffffff,4,0,0,0,0,0))
    result=M.templates(g)
    assert result['mine_loadout_blocks']==50
    records=T.template_records(g.rd(T.TEMPLATE,T.TEMPLATE_BLOCKS*T.TEMPLATE_BLOCK))
    assert sum(r[1]==0x10a and r[3]==7 for r in records)==30


def test_deployed_mine_pickup_is_blocked_but_bonus_and_traversal_prompts_remain(monkeypatch):
    from gbox.mercs.titles import re5_ps3 as R
    raw=FakeRE5();m=T.RE5(raw);target=0x30500000
    request={'kind':R.BTN_STAGE,'token':'mash:square','target':target}
    monkeypatch.setattr(R,'selected_prompt',lambda _:request)
    for vtable in R.MINE_VTABLES:
        raw.u32(target,vtable)
        assert R.prompt(m) is None and not R.stage_prompt(m)
    for vtable in (R.HOURGLASS_VT,0x015a0000):
        raw.u32(target,vtable)
        assert R.prompt(m)=='mash:square' and R.stage_prompt(m)


def test_mine_consumption_is_acknowledged_once(monkeypatch):
    monkeypatch.setattr(M,"settings",lambda:dict(M.DEFAULT,interval_s=2))
    stats={}; c=M.Controller(SimpleNamespace(),stats,lambda *a:None)
    mine={"id":0x10a,"item":10,"type":1,"slot":2,"grid":7,"rounds":5,"hand":True}
    snap={"player":{"ptr":0x303f8a00,"pos":(0,0,0),"hp":1000,"action":0},"inventory":[mine]}
    c.tick(snap,0);c.tick(snap,3)
    mine["rounds"]=4
    c.tick(snap,4);c.tick(snap,4.2)
    assert stats["mines_placed"]==1


def test_mine_equipping_keeps_combat_from_cancelling_the_change(monkeypatch):
    monkeypatch.setattr(M,'settings',lambda:dict(M.DEFAULT,interval_s=2))
    attempts=[]
    def switch(*args):
        attempts.append(args)
        return {'tap':'ddown'} if len(attempts)==1 else None
    c=M.Controller(SimpleNamespace(),{},switch)
    mine={'id':0x10a,'item':10,'type':1,'slot':2,'grid':7,'rounds':5,'hand':False}
    snap={'player':{'ptr':0x303f8a00,'pos':(0,0,0),'hp':1000,'action':0},'inventory':[mine]}
    c.tick(snap,0)
    assert c.tick(snap,3)=={'tap':'ddown'}
    assert c.tick(snap,3.4)=={'hold':set()}
    assert len(attempts)==1
